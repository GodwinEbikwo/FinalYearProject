//
//  Question.swift
//  ImDetection
//
//  Created by Godwin Adejo Ebikwo on 02/12/2018.
//  Copyright © 2018 Godwin Adejo Ebikwo. All rights reserved.
//

import Foundation

class Question
{
    var text: String = ""
    var options: Array<String> = []
    var answer: Int = 0
    var image: String = ""
    var sound: URL = URL(fileURLWithPath: "")
    var isAnswered: Bool = false
    init() {}
    init(_ text: String, _ options: Array<String>, answer: Int, image: String, sound: String? = "")
    {
        self.text = text
        self.options = options
        self.answer = answer
        self.image = image
        if(sound != "") {
            self.sound = URL(fileURLWithPath:
                Bundle.main.path(forResource: sound, ofType: "wav")!) }
    }
}

class Quiz
{
    var score: Int = 0
    var questions: Array<Question> = []
    let Q1: Question = Question("What sound does a dog make?",
        ["Meow", "Bark", "Clack-Clack", "Neigh"], answer: 2, image: "Dog1")
    let Q2: Question = Question("What family of cats does this belong to?",
        ["Tiger", "Lion", "Leopard", "Domestic"], answer: 4, image: "Cat1")
    let Q3: Question = Question("What is the animal below?",
        ["Dog", "Hen", "Horse", "Buffalo"], answer: 3, image: "Horse1")
    let Q4: Question = Question("Are butterflies insects?",
        ["Not sure", "No", "May be", "Yes"], answer: 4, image: "Butterfly1")
    let Q5: Question = Question("How many legs does an elephant have?",
        ["Four", "Three", "Six", "One"], answer: 1, image: "Elephant1")
    let Q6: Question = Question("What is the animal above called?",
        ["Bird", "Duck", "Parrot", "Dragon"], answer: 3, image: "Parrot1")
    let Q7: Question = Question("What animal makes this sound?",
        ["Cat", "Dog", "Dragon", "Duck"], answer: 1, image: "audio", sound: "Cat")
    init() { self.questions = [self.Q1, self.Q2, self.Q3, self.Q4, self.Q5, self.Q6, self.Q7] }
}
