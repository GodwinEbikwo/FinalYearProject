//
//  ViewController.swift
//  ARImageDetection
//
//  Created by Godwin Adejo Ebikwo on 03/11/2018.
//  Copyright © 2018  Godwin Adejo Ebikwo All rights reserved.
//

import UIKit
import SceneKit
import ARKit
import AVFoundation

@available(iOS, deprecated: 9.0) //Silence iOS12 deprecated warnings
class ARViewController: UIViewController, ARSCNViewDelegate {
    
    var config: ARWorldTrackingConfiguration = ARWorldTrackingConfiguration()
    var animal: Animal = Animals.get("")
    var audioPlayer: AVAudioPlayer = AVAudioPlayer()

    @IBOutlet var sceneView: ARSCNView!
    @IBOutlet var label: UILabel!
    @IBAction func restartExperience() { self.resetTracking() }
   
    @IBAction func showURL() { UIApplication.shared.open(self.animal.url) }
    @IBAction func playSound() { do {
        self.audioPlayer = try AVAudioPlayer(contentsOf: self.animal.sound)
        self.audioPlayer.play()
    }   catch {} }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.sceneView.delegate = self
        self.sceneView.showsStatistics = false
        self.sceneView.debugOptions = [.showFeaturePoints]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.resetTracking()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.sceneView.session.pause()
    }

    func resetTracking() {
        // Create a session configuration
        guard let referenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: Bundle.main) else { return }
        self.config = ARWorldTrackingConfiguration()
        self.config.detectionImages = referenceImages
        self.config.maximumNumberOfTrackedImages = 0
        self.config.isLightEstimationEnabled = true
        self.animal = Animals.get("")
        
        // Run the view's session
        self.sceneView.scene = SCNScene()
        self.sceneView.session.run(self.config)
        self.sceneView.autoenablesDefaultLighting = true
        self.sceneView.automaticallyUpdatesLighting = true
        self.label.text = "Look around to detect images"
    }
    
    // Override to create and configure nodes for anchors added to the view's session.
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        self.sceneView.scene.rootNode.enumerateChildNodes{ (node2, stop) in
            node2 .removeFromParentNode()
            guard let imageAnchor: ARImageAnchor = anchor as? ARImageAnchor else { return }
            let imageName = imageAnchor.referenceImage.name ?? "Unknown"
            DispatchQueue.main.sync { self.label.text = "Found: " + imageName }
            self.animal = Animals.get(imageName)
            
            if let currentFrame = self.sceneView.session.currentFrame {
                var translation = matrix_identity_float4x4
                translation.columns.3.z = -0.3
                let transform = simd_mul(currentFrame.camera.transform, translation)
                
                let obj = self.animal.object
                let min = obj.boundingBox.min
                let max = obj.boundingBox.max
                obj.pivot = SCNMatrix4MakeTranslation(
                    min.x + (max.x - min.x) / 2,
                    min.y + (max.y - min.y) / 2,
                    min.z + (max.z - min.z) / 2)
                
                let node = SCNNode()
                node.eulerAngles.x = -.pi / 2
                node.simdTransform = transform
                node.addChildNode(obj)
                self.sceneView.scene.rootNode.addChildNode(node)
            }
        }
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        debugPrint("Session Error: " + error.localizedDescription)
        self.resetTracking()
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        debugPrint("Session Interrupted")
        self.resetTracking()
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        debugPrint("Session Resumed")
    }
}
