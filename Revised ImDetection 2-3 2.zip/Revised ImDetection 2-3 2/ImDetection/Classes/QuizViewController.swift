//
//  QuizVC.swift
//  ImDetection
//
//  Created by Godwin Adejo Ebikwo on 13/11/2018.
//  Copyright © 2018 Godwin Adejo Ebikwo. All rights reserved.
//

import UIKit
import AVFoundation

class QuizViewController: UIViewController {
    
    var quiz: Quiz = Quiz()
    var currentQuestion: Int = 1
    var audioPlayer: AVAudioPlayer = AVAudioPlayer()
    var tapGesture: UITapGestureRecognizer = UITapGestureRecognizer()
    
    @IBOutlet var questionLabel: UILabel!
    @IBOutlet var questionImage: UIImageView!
    @IBOutlet var option1Btn: UIButton!
    @IBOutlet var option2Btn: UIButton!
    @IBOutlet var option3Btn: UIButton!
    @IBOutlet var option4Btn: UIButton!
    @IBAction func option1BtnTapped() { self.setAnswer(1) }
    @IBAction func option2BtnTapped() { self.setAnswer(2) }
    @IBAction func option3BtnTapped() { self.setAnswer(3) }
    @IBAction func option4BtnTapped() { self.setAnswer(4) }
    @IBAction func backToAR() {
        let alert: UIAlertController = UIAlertController(
            title: "Back to AR",
            message: "Are you sure you want to leave the quiz?",
            preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default,
            handler: self.leaveQuiz))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        self.present(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tapGesture.addTarget(self, action: #selector(self.questionImageTapped))
        self.questionImage.addGestureRecognizer(self.tapGesture)
        self.questionImage.isUserInteractionEnabled = true
        self.setQuestion(1)
        self.quiz.score = 0
    }
    
    @objc func questionImageTapped() { self.audioPlayer.play() }
    
    func setButtonTitle(_ Button: UIButton, _ Title: String) {
        Button.setAttributedTitle(NSAttributedString(string: Title, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]), for: .normal)
    }
    
    func setQuestion(_ number: Int) {
        let index = number - 1
        if(number > self.quiz.questions.count) { return }
        self.currentQuestion = number
        self.questionLabel.text = self.quiz.questions[index].text
        self.questionImage.image = UIImage(named: self.quiz.questions[index].image)
        do { self.audioPlayer = try AVAudioPlayer(contentsOf: self.quiz.questions[index].sound)
            self.audioPlayer.play()
        } catch {}
        self.setButtonTitle(self.option1Btn, self.quiz.questions[index].options[0])
        self.setButtonTitle(self.option2Btn, self.quiz.questions[index].options[1])
        self.setButtonTitle(self.option3Btn, self.quiz.questions[index].options[2])
        self.setButtonTitle(self.option4Btn, self.quiz.questions[index].options[3])
    }

    func setAnswer(_ number: Int) {
        var text = "Incorrect!"
        if(number == self.quiz.questions[self.currentQuestion - 1].answer) {
            self.quiz.score += 1
            text = "Correct!"
        }
        let alert: UIAlertController = UIAlertController(
            title: "Quiz", message: text, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Next Question", style: .default,
                                      handler: self.nextQuestion))
        self.present(alert, animated: true, completion: nil)
    }
    
    func nextQuestion(_action: UIAlertAction) {
        if(self.currentQuestion < self.quiz.questions.count) {
            self.setQuestion(self.currentQuestion + 1)
        }
        else {
            let msg: String = "You scored " + String(self.quiz.score) +
                "/" + String(self.quiz.questions.count) + "!"
            let alert: UIAlertController = UIAlertController(
                title: "Quiz Over", message: msg, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Back to AR", style: .default,
                                          handler: self.leaveQuiz))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func leaveQuiz(_action: UIAlertAction) {
        self.performSegue(withIdentifier: "backToAR", sender: self) }
}
