//
//  Sequencer.swift
//  ImDetection
//
//  Created by  Godwin Adejo Ebikwo on 03/11/2018.
//  Copyright © 2018 Godwin Adejo Ebikwo. All rights reserved.
//

import Foundation

class Sequencer
{
    var counter: Double = 0.0
    var timer: Timer = Timer()
    var actions: Array<() -> ()> = []
    
    init()
    {
        self.timer = Timer.scheduledTimer(timeInterval: 0.001, target: self, selector: #selector(self.loop), userInfo: nil, repeats: true)
    }
    
    func run(_ actions: Array<() -> ()>) {
        self.actions.append(contentsOf: actions) }
    
    @objc func loop()
    {
        //debugPrint(self.counter)
        if(self.counter <= 0)
        {
            if(self.actions.count > 0)
            {
                self.actions.first!() //Executes a list of instructions
                _ = self.actions.removeFirst()
            }
        }
        else { self.counter -= 0.001 }
    }
    
    func wait(_ duration: Double) -> () -> () {
        return { self.counter = duration } }
}
