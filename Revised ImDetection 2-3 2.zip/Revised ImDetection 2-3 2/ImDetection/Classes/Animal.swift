//
//  Animal.swift
//  ImDetection
//
//  Created by Godwin Adejo Ebikwo on 03/11/2018.
//  Copyright © 2018 Godwin Adejo Ebikwo. All rights reserved.
//

import SceneKit
import Foundation

class Animal
{
    var scene: SCNScene = SCNScene()
    var object: SCNNode = SCNNode()
    var sound: URL = URL(fileURLWithPath: "Sounds/Cat.wav")
    var url: URL = URL(string: "https://www.google.co.uk/")!
    
    init() {}
    init(_ scenePath: String, _ objectName: String)
    {
        self.scene = SCNScene(named: scenePath)!
        self.object = self.scene.rootNode.childNode(withName: objectName,
                                                    recursively: true)!
        self.object.eulerAngles.z = .pi / 2
        self.object.scale = SCNVector3(0.0025, 0.0025, 0.0025)
    }
}

class Animals
{
    static func get(_ name: String) -> Animal
    {
        if(name == "Frame") { return self.ARCat }
        else if(name == "Cat") { return self.Cat }
        else if(name == "Dog") { return self.Dog }
        else if(name == "Dragon") { return self.Dragon }
        else if(name == "Duck") { return self.Duck }
        else if(name == "Parrot") { return self.Parrot }
        else if(name == "Swan") { return self.Swan }
        else { return self.ARCat } //Default
    }
    
    static var ARCat: Animal =
    {
        let animal: Animal = Animal("art.scnassets/ARCat.scn", "ARCat")
        animal.object.eulerAngles.y = .pi
        animal.object.scale = SCNVector3(0.025, 0.025, 0.025)
        return animal
    }()
    
    static var Cat: Animal =
    {
        let animal: Animal = Animal("art.scnassets/Cat.scn", "Cat")
        animal.object.scale = SCNVector3(0.1, 0.1, 0.1)
        animal.sound = URL(fileURLWithPath: Bundle.main.path(forResource: "Cat", ofType: "wav")!)
        animal.url = URL(string: "https://kids.britannica.com/kids/article/cat/352924#")!
        return animal
    }()
    
    static var Dog: Animal =
    {
        let animal: Animal = Animal("art.scnassets/Dog.scn", "Dog")
        
        animal.sound = URL(fileURLWithPath: Bundle.main.path(forResource: "Dog", ofType: "wav")!)
        animal.url = URL(string: "https://kids.britannica.com/kids/article/dog/353060")!
        return animal
    }()
    
    static var Dragon: Animal =
    {
        let animal: Animal = Animal("art.scnassets/Dragon.scn", "Dragon")
        animal.sound = URL(fileURLWithPath: Bundle.main.path(forResource: "Dragon", ofType: "wav")!)
        animal.url = URL(string: "https://kids.britannica.com/kids/article/dragon/353064")!
        return animal
    }()
    
    static var Duck: Animal =
    {
        let animal: Animal = Animal("art.scnassets/Duck.scn", "Duck")
        animal.object.eulerAngles.z = .pi / 2
        animal.object.scale = SCNVector3(0.0015, 0.0015, 0.0015)
        animal.sound = URL(fileURLWithPath: Bundle.main.path(forResource: "Duck", ofType: "wav")!)
        animal.url = URL(string: "https://kids.britannica.com/kids/article/duck/390384")!
        return animal
    }()
    
    static var Parrot: Animal =
    {
        let animal: Animal = Animal("art.scnassets/Parrot.scn", "Parrot")
        animal.object.eulerAngles.z = .pi / 2
        animal.sound = URL(fileURLWithPath: Bundle.main.path(forResource: "Parrot", ofType: "wav")!)
        animal.url = URL(string: "https://kids.britannica.com/kids/article/parrot-family/353601")!
        return animal
    }()
    
    static var Swan: Animal =
    {
        let animal: Animal = Animal("art.scnassets/Swan.scn", "Swan")
        animal.object.eulerAngles.z = .pi / 2
        animal.object.scale = SCNVector3(0.0015, 0.0015, 0.0015)
        animal.url = URL(string: "https://kids.britannica.com/kids/article/swan/390138")!
        return animal
    }()
 
}
