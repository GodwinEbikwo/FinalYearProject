//
//  launchClass.swift
//  FinalProject
//
//  Created by Godwin Adejo Ebikwo on 07/10/2018.
//  Copyright © 2018 Godwin Adejo Ebikwo. All rights reserved.
//

import Foundation
import SceneKit

class LaunchClass: UIViewController {
    
    @IBOutlet var spinner: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        spinner.startAnimating()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.performSegue(withIdentifier: "launch", sender: self)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated) }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated) }
}
